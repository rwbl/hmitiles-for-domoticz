﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.5
@EndOfDesignText@
' Class Module: DomoticzWebSocketHandler
' Brief:        Manages persistent full-duplex socket channels and pushes 
'               randomized real-time weather fluctuations down to your tiles.

Sub Class_Globals
	Private ws As WebSocket         ' Holds the active socket connection container
	Private simTimer As Timer       ' Internal ticker loop engine driving real-time values
End Sub

Public Sub Initialize
	' Initialization logic if needed
End Sub

' Triggered automatically by Jetty when a dashboard client opens a network socket connection
Private Sub WebSocket_Connected (WebSocket1 As WebSocket)
	ws = WebSocket1
	Log("🟢 [WEBSOCKET CONNECTED] Dashboard client tunnel open!")
    
	' Save this live session instance reference into the Main global memory thread lane
	Main.CurrentUserSession = Me
    
	' Initialize a 3-second simulation timer loop to push fresh data streams
	simTimer.Initialize("simTimer", 3000)
	simTimer.Enabled = True
End Sub

' Triggered automatically when the user closes the browser page or navigates away
Private Sub WebSocket_Disconnected
	Log("🔴 [WEBSOCKET DISCONNECTED] Client closed tunnel path.")
    
	' FIXED: Safely disable the timer sequence directly without checking IsInitialized
	simTimer.Enabled = False
End Sub

' The core execution handler looping every 3 seconds to push random metrics
Private Sub simTimer_Tick
	' Short-circuit safety check: If the socket pipeline drops out, exit the execution path
	If ws.Open = False Then
		simTimer.Enabled = False
		Return
	End If

	Try
		' 1. COMPILE A RANDOMIZED DATA RECORD
		' Simulate real-world weather station fluctuations natively
		Dim bearing As Int = Rnd(160, 200)             ' Fluctuates around South (160° - 199°)
		Dim speedMS As Int = Rnd(10, 150)              ' Speeds varying up to 15 m/s (multiplied by 10)
		Dim gustMS As Int  = speedMS + Rnd(20, 60)     ' Gusts scale higher than base wind speeds
		Dim tempC As Int   = Rnd(170, 230)             ' Temperature shifts around 17°C - 23°C
		Dim chillC As Int  = tempC - Rnd(5, 15)        ' Windchill settles slightly below ambient air
        
		' Combine parameters using the exact semicolons data string expected by your JS engine
		Dim windCompositeString As String = bearing & ";S;" & speedMS & ";" & gustMS & ";" & tempC & ";" & chillC
        
		' 2. ASSEMBLE COMPLIANT DOMOTICZ JSON PAYLOAD
		Dim resultRoot As Map
		resultRoot.Initialize
		resultRoot.Put("status", "OK")
		resultRoot.Put("event", "deviceUpdate") ' Explicit event tag signature
        
		Dim deviceMap As Map
		deviceMap.Initialize
		deviceMap.Put("idx", "45") ' Targets your custom Wind Station component tile
		deviceMap.Put("Name", "Live Weather Station Inbound")
		deviceMap.Put("Type", "Wind")
		deviceMap.Put("Data", windCompositeString)
		deviceMap.Put("svalue", windCompositeString)
		deviceMap.Put("LastUpdate", DateTime.Date(DateTime.Now) & " " & DateTime.Time(DateTime.Now))
        
		resultRoot.Put("device", deviceMap)
        
		' Serialize the compiled telemetry data map directly into a string payload
		Dim jsonGen As JSONGenerator
		jsonGen.Initialize(resultRoot)
		Dim jsonPayload As String = jsonGen.ToString
        
		' 3. PUSH RAW DATA STRINGS DIRECTLY OVER THE CHANNEL TUNNEL
		' This fires the global listener event callback 'onServerPush' inside your web code
		ws.RunFunction("onServerPush", Array(jsonPayload))
		ws.Flush ' Flush network pipeline channel data buffers and enforce immediate transmission
        
		Log("⚡ [WEBSOCKET PUSH] Dispatched live simulation tracking packet: " & windCompositeString)
        
	Catch
		Log("⚠️  [WEBSOCKET ERROR] Loop failed during stream calculation transmission.")
		simTimer.Enabled = False
	End Try
End Sub

' Add this new public method anywhere inside your DomoticzWebSocketHandler class file:
Public Sub BroadcastLiveChange(idx As String, svalue As String)
	' Verify if the active websocket tunnel channel is fully open and initialized
	If ws.IsInitialized = False Or ws.Open = False Then Return

	Try
		' Compile a live frame transaction mapping matching your UI listener expectations
		Dim resultRoot As Map
		resultRoot.Initialize
		resultRoot.Put("status", "OK")
		resultRoot.Put("event", "deviceUpdate")
        
		Dim deviceMap As Map
		deviceMap.Initialize
		deviceMap.Put("idx", idx)
		deviceMap.Put("Name", "Live Simulation API Override")
        
		' Set the internal device types so your frontend filters them correctly
		If idx = "12" Then
			deviceMap.Put("Type", "Usage")
		Else If idx = "45" Then
			deviceMap.Put("Type", "Wind")
		Else
			deviceMap.Put("Type", "Alarm")
		End If
        
		deviceMap.Put("Data", svalue)
		deviceMap.Put("svalue", svalue)
		deviceMap.Put("LastUpdate", DateTime.Date(DateTime.Now) & " " & DateTime.Time(DateTime.Now))
        
		resultRoot.Put("device", deviceMap)
        
		Dim jsonGen As JSONGenerator
		jsonGen.Initialize(resultRoot)
        
		' Push the data straight through to the web app view window!
		ws.RunFunction("onServerPush", Array(jsonGen.ToString))
		ws.Flush
		Log($"⚡ [WEBSOCKET INTERCEPT BROADCAST] Pushed live update loop state via udevice for IDX: ${idx}"$)
	Catch
		Log("⚠️  [BROADCAST ERROR] WebSocket channel failed to pipe live change event frame.")
	End Try
End Sub
