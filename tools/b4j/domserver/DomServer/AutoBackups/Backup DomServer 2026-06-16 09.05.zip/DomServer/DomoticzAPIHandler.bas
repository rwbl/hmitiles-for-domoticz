﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=2.18
@EndOfDesignText@
' Class Module: DomoticzAPIHandler
' File: DomoticzAPIHandler
' Brief: API Query Handler

Sub Class_Globals
	' Core handler structural variables
End Sub

Public Sub Initialize
    ' Initialization logic if needed
End Sub

Sub Handle(req As ServletRequest, resp As ServletResponse)
    resp.SetHeader("Access-Control-Allow-Origin", "*")
    resp.SetHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    resp.ContentType = "application/json;charset=UTF-8"
    
    Dim commandType As String = req.GetParameter("type")
    Dim paramType As String = req.GetParameter("param")
    Dim ridString As String = req.GetParameter("rid")
    Dim filterType As String = req.GetParameter("filter") ' Extract the global tracker parameter
    
    Log($"[REQUEST] type=${commandType}, param=${paramType}, rid=${ridString}, filter=${filterType}"$)
    
    If commandType = "command" And paramType = "getdevices" Then
        Dim jsonResponse As String = ""
        
        ' CHECK IF DASHBOARD IS REQUESTING THE GLOBAL BATCH PACKET
        If filterType = "all" Then
            jsonResponse = GenerateAllMockDevices
        Else
            jsonResponse = GenerateSingleDeviceData(ridString)
        End If
        
        resp.Write(jsonResponse)
    Else
        resp.Write("{""status"" : ""ERR_UNSUPPORTED_COMMAND""}")
    End If
End Sub

' NEW: Generates the full multi-device list payload for the global dashboard fetch
Private Sub GenerateAllMockDevices As String
    Dim resultRoot As Map
    resultRoot.Initialize
    resultRoot.Put("status", "OK")
    resultRoot.Put("title", "GetDevices")
    
    Dim resultList As List
    resultList.Initialize
    
    ' Add Battery Node (IDX 12)
    Dim batteryMap As Map
    batteryMap.Initialize
    batteryMap.Put("idx", "12")
    batteryMap.Put("Name", "System Battery SOC")
    batteryMap.Put("Type", "Usage")
    batteryMap.Put("Data", "100") ' Triggers your "FULL" text rule
    batteryMap.Put("Status", "100 %")
    batteryMap.Put("LastUpdate", "2026-06-16 11:30:00")
    resultList.Add(batteryMap)
    
    ' Add Solar Generation Node (IDX 5)
    Dim solarMap As Map
    solarMap.Initialize
    solarMap.Put("idx", "5")
    solarMap.Put("Name", "Solar Generation")
    solarMap.Put("Type", "Usage")
    solarMap.Put("Data", "1252") ' Triggers your "LOW" warning rule
    solarMap.Put("Status", "1252 Watt")
    solarMap.Put("LastUpdate", "2026-06-16 11:30:00")
    resultList.Add(solarMap)
    
    ' Add Air Quality Node (IDX 31)
    Dim airMap As Map
    airMap.Initialize
    airMap.Put("idx", "31")
    airMap.Put("Name", "Air Quality Monitor")
    airMap.Put("Type", "Air Quality")
    airMap.Put("Data", "450")
    airMap.Put("Status", "450 PPM")
    airMap.Put("LastUpdate", "2026-06-16 11:30:00")
    resultList.Add(airMap)

    resultRoot.Put("result", resultList)
    
    Dim jsonGen As JSONGenerator
    jsonGen.Initialize(resultRoot)
    Return jsonGen.ToString
End Sub

' Keep your existing logic for single fallback routing intact
Private Sub GenerateSingleDeviceData(idx As String) As String
    Dim resultRoot As Map
    resultRoot.Initialize
    resultRoot.Put("status", "OK")
    resultRoot.Put("title", "GetDevices")
    
    Dim resultList As List
    resultList.Initialize
    
    Dim deviceMap As Map
    deviceMap.Initialize
    deviceMap.Put("idx", idx)
    deviceMap.Put("LastUpdate", "2026-06-16 11:30:00")
    
    Select Case idx
        Case "5"
            deviceMap.Put("Name", "Solar Generation")
            deviceMap.Put("Type", "Usage")
            deviceMap.Put("Data", "1252")
            deviceMap.Put("Status", "1252 Watt")
        Case "12"
            deviceMap.Put("Name", "System Battery SOC")
            deviceMap.Put("Type", "Usage")
            deviceMap.Put("Data", "100")
            deviceMap.Put("Status", "100 %")
        Case Else
            deviceMap.Put("Name", "Mock Node")
            deviceMap.Put("Type", "General")
            deviceMap.Put("Data", "0")
            deviceMap.Put("Status", "OK")
    End Select
    
    resultList.Add(deviceMap)
    resultRoot.Put("result", resultList)
    
    Dim jsonGen As JSONGenerator
    jsonGen.Initialize(resultRoot)
    Return jsonGen.ToString
End Sub
